# gallery-task

* Starter files for a basic html and css assignment
